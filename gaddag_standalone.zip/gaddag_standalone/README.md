# GADDAG Scrabble - Standalone

Moteur de jeu Scrabble utilisant la structure de donnees GADDAG.

## Fichiers

| Fichier | Description |
|---|---|
| `main.py` | Point d'entree - jeu en terminal |
| `gaddag.py` | Structure GADDAG (insertion, recherche, cache) |
| `node.py` | Noeud de l'arbre GADDAG |
| `board.py` | Plateau 15x15 avec multiplicateurs |
| `rack.py` | Gestion du chevalet (lettres, blanks) |
| `types_mod.py` | Types: Direction, Move, SquareType |
| `board_utils.py` | Utilitaires plateau (prefixe/suffixe) |
| `move_generator.py` | Generation de tous les coups possibles |
| `score_calculator.py` | Calcul des scores (mots croises inclus) |
| `word_validator.py` | Validation complete des placements |
| `ods8.txt` | Dictionnaire ODS8 (francais) |

## Lancer

```bash
python main.py
```

Ou avec un autre dictionnaire :

```bash
python main.py mon_dico.txt
```

## Commandes en jeu

| Commande | Exemple | Description |
|---|---|---|
| `MOT POS DIR` | `MAISON H8 H` | Jouer un mot (H=horizontal, V=vertical) |
| `aide LETTRES` | `aide AIEMNSO` | Trouver les meilleurs coups pour un chevalet |
| `verif MOT` | `verif MAISON` | Verifier si un mot existe dans le dico |
| `annuler` | `annuler` | Annuler le dernier coup |
| `q` | `q` | Quitter |

## Positions

- Lignes : A-O (haut en bas)
- Colonnes : 1-15 (gauche a droite)
- Centre : H8

## Premiere utilisation

Au premier lancement, le GADDAG est construit depuis le dictionnaire (~30s).
Un fichier `.pkl` (cache) est cree automatiquement pour accelerer les lancements suivants.

## Prerequis

- Python 3.8+
- Aucune dependance externe
