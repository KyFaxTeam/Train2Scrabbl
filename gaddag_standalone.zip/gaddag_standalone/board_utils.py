from board import Board
from types_mod import Direction


class BoardUtils:
    """Utilitaires pour manipuler le plateau de jeu."""

    @staticmethod
    def get_prefix(board: Board, row: int, col: int, direction: Direction) -> str:
        prefix = []
        current_row, current_col = row, col
        while True:
            if direction == Direction.HORIZONTAL:
                current_col -= 1
            else:
                current_row -= 1
            if not (0 <= current_row < board.size and 0 <= current_col < board.size):
                break
            letter = board.get_letter(current_row, current_col)
            if not letter:
                break
            prefix.insert(0, letter)
        return ''.join(prefix)

    @staticmethod
    def get_suffix(board: Board, row: int, col: int, direction: Direction) -> str:
        suffix = []
        current_row, current_col = row, col
        while True:
            if direction == Direction.HORIZONTAL:
                current_col += 1
            else:
                current_row += 1
            if not (0 <= current_row < board.size and 0 <= current_col < board.size):
                break
            letter = board.get_letter(current_row, current_col)
            if not letter:
                break
            suffix.append(letter)
        return ''.join(suffix)
