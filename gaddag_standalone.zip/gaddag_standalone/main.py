#!/usr/bin/env python3
"""
Scrabble en terminal avec GADDAG.

Usage:
    python main.py [chemin_dictionnaire]

Par defaut, cherche 'ods8.txt' dans le dossier courant.
"""
import sys
import os
import time
import logging

from gaddag import GADDAG
from board import Board
from rack import Rack
from types_mod import Direction, Move
from move_generator import MoveGenerator
from score_calculator import ScoreCalculator
from word_validator import WordValidator

logging.basicConfig(level=logging.WARNING)


def display_board(board: Board):
    """Affiche le plateau avec couleurs ANSI."""
    # En-tete colonnes
    print("\n     ", end="")
    for i in range(board.size):
        print(f"{i+1:3}", end="")
    print()
    print("    +" + "---" * board.size + "+")

    for row in range(board.size):
        print(f"  {chr(65 + row)} |", end="")
        for col in range(board.size):
            letter = board.get_letter(row, col)
            if letter:
                print(f" \033[1;33m{letter}\033[0m ", end="")
            elif (row, col) == (7, 7):
                print(" \033[1;31m*\033[0m ", end="")
            elif (row, col) in Board.TRIPLE_WORD_SCORE:
                print(" \033[31mT\033[0m ", end="")  # rouge = mot triple
            elif (row, col) in Board.DOUBLE_WORD_SCORE:
                print(" \033[35mD\033[0m ", end="")  # magenta = mot double
            elif (row, col) in Board.TRIPLE_LETTER_SCORE:
                print(" \033[34mt\033[0m ", end="")  # bleu = lettre triple
            elif (row, col) in Board.DOUBLE_LETTER_SCORE:
                print(" \033[36md\033[0m ", end="")  # cyan = lettre double
            else:
                print(" . ", end="")
        print("|")

    print("    +" + "---" * board.size + "+")
    print("  Legende: \033[31mT\033[0m=Mot Triple  \033[35mD\033[0m=Mot Double  "
          "\033[34mt\033[0m=Lettre Triple  \033[36md\033[0m=Lettre Double  "
          "\033[1;31m*\033[0m=Centre")


def display_rack(rack_str: str):
    print(f"\n  Chevalet: [ {' '.join(rack_str.upper())} ]")


def get_best_moves(generator: MoveGenerator, rack_str: str, top_n: int = 10):
    """Genere et trie les meilleurs coups."""
    moves = generator.generate_moves(rack_str)
    moves.sort(key=lambda m: m.score, reverse=True)
    return moves[:top_n]


def display_moves(moves, top_n=10):
    if not moves:
        print("\n  Aucun coup possible !")
        return
    print(f"\n  === Top {min(len(moves), top_n)} coups possibles ===")
    for i, move in enumerate(moves[:top_n], 1):
        pos = f"{chr(65 + move.row)}{move.col + 1}"
        d = "H" if move.direction == Direction.HORIZONTAL else "V"
        print(f"  {i:2}. {move.word:<15} {pos:>4} {d}  {move.score:>3} pts")


def play_move_on_board(board: Board, validator: WordValidator, word: str,
                       row: int, col: int, direction: Direction) -> int:
    """Place un mot sur le plateau et retourne le score. Retourne -1 si invalide."""
    calc = ScoreCalculator(board)
    move = Move(word=word, row=row, col=col, direction=direction)

    # Validation
    is_first_move = board.is_empty()
    valid, formed_words, msg = validator.validate_placement_complete(
        word, row, col, direction, check_connection=True
    )

    if not valid:
        print(f"  \033[31mCoup invalide: {msg}\033[0m")
        return -1

    score = calc.calculate_move_score(move)
    board.apply_move(move, score)
    return score


def parse_input(user_input: str, board: Board):
    """Parse l'input: MOT POSITION DIRECTION (ex: MAISON H8 H)"""
    parts = user_input.strip().upper().split()
    if len(parts) != 3:
        return None, None, None, None

    word = parts[0]
    coord_str = parts[1]
    dir_str = parts[2]

    if dir_str not in ('H', 'V'):
        return None, None, None, None

    try:
        row, col = board.parse_coordinates(coord_str)
    except ValueError:
        return None, None, None, None

    direction = Direction.HORIZONTAL if dir_str == 'H' else Direction.VERTICAL
    return word, row, col, direction


def main():
    dict_path = sys.argv[1] if len(sys.argv) > 1 else "ods8.txt"

    if not os.path.exists(dict_path):
        print(f"Erreur: dictionnaire '{dict_path}' introuvable.")
        print("Usage: python main.py [chemin_dictionnaire]")
        sys.exit(1)

    print("=" * 55)
    print("       SCRABBLE  -  Moteur GADDAG")
    print("=" * 55)

    # Chargement GADDAG (avec cache pickle)
    print(f"\nChargement du dictionnaire: {dict_path}")
    start = time.time()
    gaddag = GADDAG.load_with_cache(dict_path)
    elapsed = time.time() - start
    stats = gaddag.get_statistics()
    print(f"  {stats['word_count']} mots charges en {elapsed:.2f}s")
    print(f"  {stats['node_count']} noeuds, {stats['transition_count']} transitions")

    board = Board()
    validator = WordValidator(board, gaddag)
    total_score = 0

    print("\n--- Commandes ---")
    print("  JOUER   : <MOT> <POSITION> <H|V>    ex: MAISON H8 H")
    print("  AIDE    : aide <CHEVALET>            ex: aide AIEMNSO")
    print("  VERIF   : verif <MOT>                ex: verif MAISON")
    print("  ANNULER : annuler")
    print("  QUITTER : q")
    print("-" * 40)

    while True:
        display_board(board)
        print(f"\n  Score total: {total_score} pts")

        user_input = input("\n> ").strip()
        if not user_input:
            continue

        cmd = user_input.split()[0].lower()

        if cmd == 'q' or cmd == 'quitter':
            print(f"\nPartie terminee ! Score final: {total_score} pts")
            break

        elif cmd == 'aide':
            parts = user_input.split()
            if len(parts) < 2:
                print("  Usage: aide <CHEVALET>  (ex: aide AIEMNSO)")
                continue
            rack_str = parts[1].upper()
            print(f"\n  Recherche des meilleurs coups pour [{rack_str}]...")
            generator = MoveGenerator(gaddag, board)
            moves = get_best_moves(generator, rack_str, top_n=15)
            display_moves(moves, top_n=15)

        elif cmd == 'verif':
            parts = user_input.split()
            if len(parts) < 2:
                print("  Usage: verif <MOT>")
                continue
            word = parts[1].upper()
            if gaddag.contains(word):
                print(f"  \033[32m'{word}' est dans le dictionnaire.\033[0m")
            else:
                print(f"  \033[31m'{word}' n'est PAS dans le dictionnaire.\033[0m")

        elif cmd == 'annuler':
            result = board.undo_last_move()
            if result:
                move, score = result
                total_score -= score
                print(f"  Coup annule: {move.word} (-{score} pts)")
            else:
                print("  Rien a annuler.")

        else:
            # Tentative de jouer un coup
            word, row, col, direction = parse_input(user_input, board)
            if word is None:
                print("  Format: <MOT> <POSITION> <H|V>  (ex: MAISON H8 H)")
                continue

            score = play_move_on_board(board, validator, word, row, col, direction)
            if score >= 0:
                total_score += score
                print(f"  \033[32m+{score} pts pour '{word}'\033[0m")


if __name__ == "__main__":
    main()
