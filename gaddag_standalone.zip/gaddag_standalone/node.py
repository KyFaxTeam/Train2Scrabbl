from typing import Dict, Optional

class Node:
    """Represente un noeud dans le GADDAG."""

    def __init__(self):
        self.transitions: Dict[str, 'Node'] = {}
        self.is_terminal: bool = False

    def add_transition(self, char: str, node: Optional['Node'] = None) -> 'Node':
        if char not in self.transitions:
            self.transitions[char] = node if node else Node()
        return self.transitions[char]

    def get_transition(self, char: str) -> Optional['Node']:
        return self.transitions.get(char)

    def has_transition(self, char: str) -> bool:
        return char in self.transitions
