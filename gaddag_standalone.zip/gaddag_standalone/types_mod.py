from enum import Enum
from dataclasses import dataclass

class SquareType(Enum):
    NORMAL = 0
    DOUBLE_LETTER = 1
    TRIPLE_LETTER = 2
    DOUBLE_WORD = 3
    TRIPLE_WORD = 4
    START = 5

class Direction(Enum):
    HORIZONTAL = 'H'
    VERTICAL = 'V'

@dataclass
class Move:
    word: str
    row: int
    col: int
    direction: Direction
    score: int = 0

    def __str__(self) -> str:
        return f"{self.word} en {chr(65+self.row)}{self.col+1} {self.direction.value} ({self.score} pts)"
