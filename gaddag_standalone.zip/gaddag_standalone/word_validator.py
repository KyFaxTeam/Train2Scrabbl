from typing import List, Tuple, Optional
from board import Board
from gaddag import GADDAG
from types_mod import Direction
from board_utils import BoardUtils


class WordValidator:
    """Valide les mots et les coups au Scrabble."""

    def __init__(self, board: Board, gaddag: GADDAG):
        self.board = board
        self.gaddag = gaddag
        self.board_utils = BoardUtils()

    def is_valid_word(self, word: str) -> bool:
        return self.gaddag.contains(word)

    def validate_placement_complete(
        self, word: str, row: int, col: int, direction: Direction,
        check_connection: bool = True
    ) -> Tuple[bool, List[str], str]:
        mots_formes = []

        if direction == Direction.HORIZONTAL:
            if col < 0 or col + len(word) > self.board.size:
                return False, [], "Depasse les limites horizontales"
        else:
            if row < 0 or row + len(word) > self.board.size:
                return False, [], "Depasse les limites verticales"

        if not self.is_valid_word(word):
            return False, [], f"'{word}' n'existe pas dans le dictionnaire"

        mot_etendu = self._get_extended_word(word, row, col, direction)
        if mot_etendu != word:
            if not self.is_valid_word(mot_etendu):
                return False, [], f"Extension invalide: '{mot_etendu}'"
            mots_formes.append(mot_etendu)
        else:
            mots_formes.append(word)

        has_connection = False

        for i, letter in enumerate(word):
            if direction == Direction.HORIZONTAL:
                curr_row, curr_col = row, col + i
            else:
                curr_row, curr_col = row + i, col

            existing = self.board.get_letter(curr_row, curr_col)
            if existing:
                if existing != letter:
                    return False, [], f"Conflit: '{existing}' != '{letter}' en ({curr_row},{curr_col})"
                has_connection = True
            else:
                cross_word = self._get_formed_cross_word(curr_row, curr_col, direction, letter)
                if cross_word and len(cross_word) > 1:
                    if not self.is_valid_word(cross_word):
                        return False, [], f"Mot croise invalide: '{cross_word}' en ({curr_row},{curr_col})"
                    mots_formes.append(cross_word)
                    has_connection = True

        if not has_connection and check_connection:
            if direction == Direction.HORIZONTAL:
                if col > 0 and self.board.get_letter(row, col - 1):
                    has_connection = True
                if col + len(word) < self.board.size and self.board.get_letter(row, col + len(word)):
                    has_connection = True
            else:
                if row > 0 and self.board.get_letter(row - 1, col):
                    has_connection = True
                if row + len(word) < self.board.size and self.board.get_letter(row + len(word), col):
                    has_connection = True

        if not has_connection and check_connection:
            for i in range(len(word)):
                if direction == Direction.HORIZONTAL:
                    curr_row, curr_col = row, col + i
                else:
                    curr_row, curr_col = row + i, col
                if self._has_adjacent_letter(curr_row, curr_col, direction):
                    has_connection = True
                    break

        if check_connection and not has_connection:
            if self.board.is_empty():
                center = self.board.size // 2
                passes_center = False
                for i in range(len(word)):
                    if direction == Direction.HORIZONTAL:
                        if row == center and col <= center < col + len(word):
                            passes_center = True
                            break
                    else:
                        if col == center and row <= center < row + len(word):
                            passes_center = True
                            break
                if not passes_center:
                    return False, [], "Premier mot doit passer par le centre"
            else:
                return False, [], "Pas de connexion avec les mots existants"

        return True, mots_formes, "OK"

    def _get_extended_word(self, word: str, row: int, col: int, direction: Direction) -> str:
        prefix = ""
        if direction == Direction.HORIZONTAL:
            c = col - 1
            while c >= 0 and self.board.get_letter(row, c):
                prefix = self.board.get_letter(row, c) + prefix
                c -= 1
        else:
            r = row - 1
            while r >= 0 and self.board.get_letter(r, col):
                prefix = self.board.get_letter(r, col) + prefix
                r -= 1

        suffix = ""
        if direction == Direction.HORIZONTAL:
            c = col + len(word)
            while c < self.board.size and self.board.get_letter(row, c):
                suffix += self.board.get_letter(row, c)
                c += 1
        else:
            r = row + len(word)
            while r < self.board.size and self.board.get_letter(r, col):
                suffix += self.board.get_letter(r, col)
                r += 1

        return prefix + word + suffix

    def _get_formed_cross_word(self, row: int, col: int, main_direction: Direction, new_letter: str) -> Optional[str]:
        cross_direction = Direction.VERTICAL if main_direction == Direction.HORIZONTAL else Direction.HORIZONTAL
        prefix = self.board_utils.get_prefix(self.board, row, col, cross_direction)
        suffix = self.board_utils.get_suffix(self.board, row, col, cross_direction)
        if not prefix and not suffix:
            return None
        return prefix + new_letter + suffix

    def _has_adjacent_letter(self, row: int, col: int, main_direction: Direction) -> bool:
        if main_direction == Direction.HORIZONTAL:
            if row > 0 and self.board.get_letter(row - 1, col):
                return True
            if row < self.board.size - 1 and self.board.get_letter(row + 1, col):
                return True
        else:
            if col > 0 and self.board.get_letter(row, col - 1):
                return True
            if col < self.board.size - 1 and self.board.get_letter(row, col + 1):
                return True
        return False

    def is_valid_move(self, word: str, row: int, col: int, direction: Direction) -> bool:
        if not self.is_valid_word(word):
            return False
        if direction == Direction.HORIZONTAL:
            if col + len(word) > self.board.size:
                return False
        else:
            if row + len(word) > self.board.size:
                return False
        for i in range(len(word)):
            curr_row = row + (i if direction == Direction.VERTICAL else 0)
            curr_col = col + (i if direction == Direction.HORIZONTAL else 0)
            existing = self.board.get_letter(curr_row, curr_col)
            if existing and existing != word[i]:
                return False
        for i, letter in enumerate(word):
            current_row = row + (i if direction == Direction.VERTICAL else 0)
            current_col = col + (i if direction == Direction.HORIZONTAL else 0)
            if not self.board.get_letter(current_row, current_col):
                cross_word = self._get_formed_cross_word(current_row, current_col, direction, letter)
                if cross_word and len(cross_word) > 1:
                    if not self.is_valid_word(cross_word):
                        return False
        return True
